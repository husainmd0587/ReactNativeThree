import React from 'react';
import { SafeAreaView, View, Text, StyleSheet } from 'react-native';
import { getCommandById } from '../commands/registry';

// Milestone 1 only proves the navigation flow (Home -> command -> here).
// The touch interaction, geometry, and validator pipeline for `line`
// (spec section 12-15) is a separate milestone.
export default function CommandPractice({ route }) {
  const commandId = route?.params?.commandId;
  const command = getCommandById(commandId);

  if (!command) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.center}>
          <Text style={styles.title}>Command not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.body}>
        <Text style={styles.title}>{command.name}</Text>
        <Text style={styles.desc}>{command.description}</Text>
        <View style={styles.placeholder}>
          <Text style={styles.placeholderText}>
            Practice canvas coming soon.
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  body: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: '700', color: '#1A1A2E' },
  desc: { fontSize: 13, color: '#8A8A9A', marginTop: 6, lineHeight: 18 },
  placeholder: {
    flex: 1,
    marginTop: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E8E6F0',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: { fontSize: 13, color: '#B7B7C0' },
});
